# Data files

The original Kaggle stock dataset and all derived files are excluded from Git to keep the repository lightweight. See the project root README for the dataset link and download instructions. Do not commit Kaggle credentials or the large generated Parquet/CSV files.
